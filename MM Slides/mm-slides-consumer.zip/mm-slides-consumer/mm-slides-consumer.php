<?php

/**
 * Plugin Name: MM Slides Consumer
 * Description: Pulls remote slides via RSS and renders a Simple Slider compatible markup.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

final class MM_Slides_Consumer
{
    const OPT_FEED_URL = 'mm_remote_slides_feed';
    const OPT_CACHE    = 'mm_remote_slides_cache';
    const CRON_HOOK    = 'mm_fetch_remote_slides';

    public function __construct()
    {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);

        add_action('init', [$this, 'maybe_schedule']);
        add_action(self::CRON_HOOK, [$this, 'fetch_and_store']);

        add_shortcode('mm_remote_slider', [$this, 'shortcode_slider']);
    }

    public function admin_menu()
    {
        add_options_page('MM Remote Slides', 'MM Remote Slides', 'manage_options', 'mm-remote-slides', [$this, 'settings_page']);
    }

    public function register_settings()
    {
        register_setting('mm_remote_slides', self::OPT_FEED_URL, ['type' => 'string', 'sanitize_callback' => 'esc_url_raw']);
    }

    public function settings_page()
    {
?>
        <div class="wrap">
            <h1>MM Remote Slides</h1>
            <form method="post" action="options.php">
                <?php settings_fields('mm_remote_slides'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="feed">Feed URL</label></th>
                        <td><input name="<?php echo esc_attr(self::OPT_FEED_URL); ?>" id="feed" type="url" class="regular-text" value="<?php echo esc_attr(get_option(self::OPT_FEED_URL)); ?>" placeholder="https://master-site.tld/feed/mm-slides?location=barrie"></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
            <form method="post">
                <?php wp_nonce_field('mm_force_fetch', 'mm_force_fetch_nonce'); ?>
                <p><button class="button button-primary" name="mm_force_fetch" value="1">Fetch Now</button></p>
            </form>
        </div>
        <?php
        if (!empty($_POST['mm_force_fetch']) && check_admin_referer('mm_force_fetch', 'mm_force_fetch_nonce')) {
            $this->fetch_and_store();
            echo '<div class="updated"><p>Fetched.</p></div>';
        }
    }

    public function maybe_schedule()
    {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 120, 'hourly', self::CRON_HOOK);
        }
    }

    public function fetch_and_store()
    {
        $url = get_option(self::OPT_FEED_URL);
        if (!$url) return;
        $res = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($res)) return;

        $body = wp_remote_retrieve_body($res);
        if (!$body) return;

        // Parse RSS
        $xml = simplexml_load_string($body);
        if (!$xml || !$xml->channel || !$xml->channel->item) return;

        $ns = $xml->getNamespaces(true);
        $slides = [];

        foreach ($xml->channel->item as $item) {
            $title = (string)$item->title;
            $desc  = (string)$item->description; // HTML in CDATA
            $data  = [];
            if (isset($ns['mm'])) {
                $mm = $item->children($ns['mm']);
                if (isset($mm->data)) {
                    $json = (string)$mm->data;
                    $data = json_decode($json, true) ?: [];
                }
            }
            $slides[] = [
                'title'   => $title,
                'desc'    => $desc,
                'subtitle' => $data['subtitle'] ?? '',
                'active'  => $data['active'] ?? 'no',
                'bg'      => $data['bg_image'] ?? '',
                'url1'    => ['text' => $data['btn1_text'] ?? '', 'url' => $data['btn1_url'] ?? ''],
                'url2'    => ['text' => $data['btn2_text'] ?? '', 'url' => $data['btn2_url'] ?? ''],
            ];
        }

        update_option(self::OPT_CACHE, [
            'updated' => current_time('timestamp'),
            'slides'  => $slides
        ], false);
    }

    public function shortcode_slider($atts)
    {
        $atts = shortcode_atts([
            'autoplay' => 'no',         // yes|no
            'speed'    => 9000,         // ms
            'style'    => 'default',    // default|full-width|full-screen (class only)
        ], $atts);

        $cache = get_option(self::OPT_CACHE);
        $slides = $cache['slides'] ?? [];
        if (!$slides) return '<!-- mm_remote_slider: no slides -->';

        ob_start(); ?>
        <div class="master-slider slider-<?php echo esc_attr($atts['style']); ?>" data-config='<?php echo json_encode([
                                                                                                    'autoplay' => $atts['autoplay'],
                                                                                                    'autoplaySpeed' => (int)$atts['speed'],
                                                                                                    'kenburns' => 'no',
                                                                                                ]); ?>'>
            <div class="bg-wrap">
                <?php $foundActive = false;
                foreach ($slides as $s):
                    $active = ($s['active'] === 'yes' && !$foundActive) ? ' active' : '';
                    if ($active) $foundActive = true; ?>
                    <div class="bg<?php echo esc_attr($active); ?>" style="<?php echo $s['bg'] ? 'background-image:url(' . esc_url($s['bg']) . ');' : ''; ?>"></div>
                <?php endforeach; ?>
            </div>

            <div class="content-wrap">
                <?php $foundActive = false;
                foreach ($slides as $s):
                    $active = ($s['active'] === 'yes' && !$foundActive) ? ' active' : '';
                    if ($active) $foundActive = true; ?>
                    <div class="slide<?php echo esc_attr($active); ?>">
                        <?php if (!empty($s['subtitle'])): ?><div class="sub-title"><?php echo esc_html($s['subtitle']); ?></div><?php endif; ?>
                        <?php if (!empty($s['title'])): ?><h1 class="title"><?php echo esc_html($s['title']); ?></h1><?php endif; ?>
                        <?php if (!empty($s['desc'])): ?><div class="desc"><?php echo wp_kses_post($s['desc']); ?></div><?php endif; ?>
                        <div class="url-wrap">
                            <?php if (!empty($s['url1']['url'])): ?>
                                <div class="slide-url url1"><a class="master-button big" href="<?php echo esc_url($s['url1']['url']); ?>"><span class="inner"><span class="content-base"><?php echo esc_html($s['url1']['text'] ?: 'Learn more'); ?></span></span><span class="bg-hover"></span></a></div>
                            <?php endif; ?>
                            <?php if (!empty($s['url2']['url'])): ?>
                                <div class="slide-url url2"><a class="master-link" href="<?php echo esc_url($s['url2']['url']); ?>"><?php echo esc_html($s['url2']['text'] ?: 'More'); ?></a></div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="control-wrap">
                <div class="nav-arrow">
                    <div class="arrow arrow-prev"></div>
                    <div class="arrow arrow-next"></div>
                </div>
                <div class="nav-dots"></div>
            </div>
        </div>
<?php
        return ob_get_clean();
    }
}

new MM_Slides_Consumer();
